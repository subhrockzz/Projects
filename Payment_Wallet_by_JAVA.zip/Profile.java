import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;


public class Profile extends JFrame implements ActionListener{
    JLabel l1,l2, l3, l6, l7, l8;
    JTextField tf1, tf2, tf5, tf6, tf7;
    JButton b1;
    String email;
    Profile(String email)
    {
        setVisible(true);
        setSize(700,700);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Profile");

        this.email = email;

//        l1 = new JLabel("User Id");
//        l2 = new JLabel("Amount");
//        l3=new JLabel("Password");

        l1 = new JLabel("YOUR WANT2PAY PROFILE");
        l1.setForeground(Color.blue);
        l1.setFont(new Font("Serif", Font.BOLD, 20));
        l2 = new JLabel("Name:");
        l3 = new JLabel("Email-ID:");
        l6 = new JLabel("Country:");
        l7 = new JLabel("State:");
        l8 = new JLabel("Phone No:");
        tf1 = new JTextField();
        tf1.setEditable(false);
        tf2 = new JTextField();
        tf2.setEditable(false);
        tf5 = new JTextField();
        tf5.setEditable(false);
        tf6 = new JTextField();
        tf6.setEditable(false);
        tf7 = new JTextField();
        tf7.setEditable(false);

        b1 = new JButton("Back");
        b1.addActionListener(this);

        l1.setBounds(100, 30, 400, 30);
        l2.setBounds(80, 70, 200, 30);
        l3.setBounds(80, 110, 200, 30);
        l6.setBounds(80, 150, 200, 30);
        l7.setBounds(80, 190, 200, 30);
        l8.setBounds(80, 230, 200, 30);
        tf1.setBounds(300, 70, 200, 30);
        tf2.setBounds(300, 110, 200, 30);
        tf5.setBounds(300, 150, 200, 30);
        tf6.setBounds(300, 190, 200, 30);
        tf7.setBounds(300, 230, 200, 30);
        b1.setBounds(50, 350, 100, 30);

        Container c = getContentPane();
        c.setBackground(new Color(22,55,46));

        l1.setForeground(Color.white);
        l2.setForeground(Color.white);
        l3.setForeground(Color.white);
        l6.setForeground(Color.white);
        l7.setForeground(Color.white);
        l8.setForeground(Color.white);

        add(l1);
        add(l2);
        add(tf1);
        add(l3);
        add(tf2);
        add(l6);
        add(tf5);
        add(l7);
        add(tf6);
        add(l8);
        add(tf7);
        add(b1);


        try
        {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/want2pay", "root", "");
            Statement stmt=con.createStatement();
            ResultSet rs = stmt.executeQuery("select name, email, country, state, phone from info where email=\"" + email + "\";");
            if(rs.next())
            {
                tf1.setText(rs.getString(1));
                tf2.setText(rs.getString(2));
                tf5.setText(rs.getString(3));
                tf6.setText(rs.getString(4));
                tf7.setText(rs.getString(5));
            }
            con.close();
        }
        catch(Exception exception)
        {
            System.out.println(exception);
        }


//        l1.setBounds(10,10,100,50);
//        l2.setBounds(10,100,200,50);
//        l3.setBounds(100,280,200,50);
//        b1.setBounds(600,10,100,50);

//        add(l1);
//        add(l2);
//        add(l3);
//        add(b1);

    }
    public void actionPerformed(ActionEvent e)
    { 
  /*  l1.setText("User Id:Subhrockzz");
    l2.setText("Amount:7500");
    l3.setText("History");*/

        if(e.getSource()==b1)
        {
            dispose();
            new Main(email);
        }
    }
//      public static void main(String args[])
//     {
//     new Profile();
//     }
}
