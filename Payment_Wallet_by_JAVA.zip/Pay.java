import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Pay extends JFrame implements ActionListener{
 JLabel l1,l2,l3;
 JButton b1,b2;
 JTextField t2;
 JComboBox<String> t1;
 String email;
 Pay(String email)
 {
  setVisible(true);
  setSize(800,500);
  setLayout(null);
  setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  setTitle("Pay");

  this.email=email;

  l1 = new JLabel("Enter UserId");
  l2 = new JLabel("Enter Amount");
  b1 = new JButton("Pay");
//     t1 = new JTextField();


  String emails[] = {""};

  try
  {
   Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/want2pay", "root", "");
   Statement stmt=con.createStatement();
   ResultSet rs = stmt.executeQuery("select email from info;");
   if (rs != null)
   {
    rs.last();
    emails = new String[rs.getRow()-1];
    rs.beforeFirst();
    int i=0;
    while(rs.next()) {
     if(!rs.getString(1).equals(email)) {
      emails[i] = rs.getString(1);
      i++;
     }
    }
   }
   con.close();
  }
  catch(Exception exception)
  {
   System.out.println(exception);
  }


  t1 = new JComboBox<String>(emails);
  t2 = new JTextField();
  l3 = new JLabel();
  b2 = new JButton("Back");

  b1.addActionListener(this);
  b2.addActionListener(this);

  l1.setBounds(10,10,100,50);
  b1.setBounds(150,200,80,30);
  t1.setBounds(130,10,200,50);
  l2.setBounds(10,100,200,50);
  t2.setBounds(130,100,200,50);
  l3.setBounds(100,280,200,50);
  b2.setBounds(600,10,80,30);

  l1.setForeground(Color.white);
  l2.setForeground(Color.white);
  l3.setForeground(Color.white);

  Container c = getContentPane();
  c.setBackground(new Color(22,55,46));


  add(l1);
  add(b1);
  add(l2);
  add(t1);
  add(t2);
  add(l3);
  add(b2);

 }
 public void actionPerformed(ActionEvent e)
 {

  String s=t1.getItemAt(t1.getSelectedIndex());

  String s2=t2.getText();
//  s=t1.getText();

  Object o=e.getSource();
  if(o==b1)
  {
   //if( s.length()==0 && s2.length()==0) {//JOptionPane.showMessageDialog(b1, "Enter UserId or Amount");}

//   if(s.equals("Subhrajeet")){
    if (t1.getSelectedIndex() >= 0) {

     try {

      double a = Double.parseDouble(t2.getText());
      Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/want2pay", "root", "");
      Statement stmt = con.createStatement();
      System.out.println(email);
      ResultSet rs = stmt.executeQuery("select balance from balance where email=\"" + email + "\";");
      rs.next();
      double b = rs.getDouble(1);
      b = b - a;
      stmt.executeUpdate("update balance set balance=" + b + " where email=\"" + email + "\";");

      rs = stmt.executeQuery("select balance from balance where email=\"" + s + "\";");
      rs.next();
      double b2 = rs.getDouble(1);
      b2 = b2 + a;
      stmt.executeUpdate("update balance set balance=" + b2 + " where email=\"" + s + "\";");

//     Date dNow = new Date();
//     SimpleDateFormat ft = new SimpleDateFormat ("yyyy-MM-dd hh:mm:ss");
//
//     System.out.println("Current Date: " + ft.format(dNow));
      stmt.executeUpdate("insert into transaction values(\"" + email + "\", " + "\"" + s + "\", " + (-a) + ", now());");
      stmt.executeUpdate("insert into transaction values(\"" + s + "\", " + "\"" + email + "\", " + a + ", now());");

      l3.setText("Upadted Money is:" + b);
      JOptionPane.showMessageDialog(b1, "Money Paid Succesfully");


      con.close();
     } catch (Exception exception) {
      System.out.println(exception);
     }
    } else {
     l3.setText("Invalid UserId");
    }
   //}
   //else{JOptionPane.showMessageDialog(b1, "Enter UserId or Amount");}
  }
  if(o==b2)
  {
   new Main(email);
  }
 }
//    public static void main(String args[])
//     {
//     new Pay();
//     }
}
