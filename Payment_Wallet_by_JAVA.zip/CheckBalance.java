import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class CheckBalance extends JFrame implements ActionListener{
    JLabel l1,l2;
    JButton b1,b2;
    String email;
    
    CheckBalance(String email)
    {
     setVisible(true);  
     setSize(800,400);
     setLayout(null);  
     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
     setTitle("Check Balance");

     this.email = email;
     
     l1 = new JLabel("Check Balance");  
     l2 = new JLabel(); 
     b1 = new JButton("Balance");
     b2 = new JButton("Back");
     
     b1.addActionListener(this); 
     b2.addActionListener(this);
     
     l1.setBounds(10,10,200,50);
     l2.setBounds(150,80,300,50);
     b1.setBounds(250,10,100,50);
     b2.setBounds(600,10,80,30);

        Container c = getContentPane();
        c.setBackground(new Color(22,55,46));

        l1.setForeground(Color.white);
        l2.setForeground(Color.white);
     
     add(l1);
     add(b1);
     add(l2);
     add(b2);
    }
      public void actionPerformed(ActionEvent e)   
    { 
    Object b=e.getSource();
      //int a=10000;
      if(b==b1)
      {
          try
          {
              Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/want2pay", "root", "");
              Statement stmt=con.createStatement();
              System.out.println(email);
              ResultSet rs = stmt.executeQuery("select balance from balance where email=\""+email+"\";");
              rs.next();
              double a = rs.getDouble(1);
              l2.setText("Your Available Balance is  " + a);

              con.close();
          }
          catch(Exception exception)
          {
              System.out.println(exception);
          }

      }
      if(b==b2)
      {
      dispose();
      new Main(email);
      }
      }
// public static void main(String args[])
//     {
//     new CheckBalance();
//     }
}
     
     
    
