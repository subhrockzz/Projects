
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Color;
public class FrontPage extends JFrame implements ActionListener{
    JLabel j,n,e;
    JButton b1,b2;
    JFrame jframe;



        FrontPage()
    {

        setLayout(null);

        setVisible(true);
        setSize(700,400);
        setBackground(Color.black);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        j=new JLabel("WELCOME TO WANT2PAY");
        b1=new JButton("SIGN UP");
        b2=new JButton("LOG IN");
        n=new JLabel("NEW USER ?");
        e=new JLabel("EXISTING USER ?");
        jframe=new JFrame();

        b1.addActionListener(this);
        b2.addActionListener(this);


        b1.setBounds(250,100,100,50);
        b2.setBounds(250,200,100,50);
        j.setBounds(200,0,400,70);
        n.setBounds(10,100,200,50);
        e.setBounds(10,200,200,50);

        n.setForeground(Color.white);
        e.setForeground(Color.white);
        j.setForeground(Color.white);

        //jframe.setForeground(Color.black);
        //jframe.getContentPane().setBackground(new Color(61,33,84));
        j.setForeground(new Color(211,208,167));
        b1.setBackground(new Color(238,218,214));
        b2.setBackground(new Color(238,218,214));
        //b2.setForeground(new Color(61,33,84));
        j.setFont(new Font("Serif",Font.BOLD,22));
        n.setFont(new Font("Serif",Font.BOLD,22));
        e.setFont(new Font("Serif",Font.BOLD,22));
        b1.setFont(new Font("Serif",Font.BOLD,15));
        b2.setFont(new Font("Serif",Font.BOLD,15));


        add(j);
        add(b1);
        add(b2);
        add(n);
        add(e);

        Container c = getContentPane();
        c.setBackground(new Color(61,33,84));

    }


    public void actionPerformed(ActionEvent e)
    {  Object see = e.getSource();
        if(see==b1)
        {
            dispose();

            new Registration();

        }
        if(see==b2)
        {
            dispose();
            Login l=new Login();
            l.setVisible(true);
        }



    }
    public static void main(String []args)
    {
        new FrontPage();
    }
}
