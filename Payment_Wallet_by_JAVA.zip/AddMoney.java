import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*;
import java.sql.*;

public class AddMoney extends JFrame implements ActionListener{
    JLabel l1,l2;
    JButton b1,b2;
    JTextField t1;
    String email;
    AddMoney(String email)
    {
     setVisible(true);  
     setSize(800,400);
     setLayout(null);  
     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
     setTitle("Add Money");

     this.email = email;
     
     l1 = new JLabel("Enter Amount");  
     l2 = new JLabel();  
     b1 = new JButton("Add");  
     t1 = new JTextField();  
     b2 = new JButton("Back");
    
     b1.addActionListener(this);  
     b2.addActionListener(this); 
     
     l1.setBounds(10,10,100,50);
     b1.setBounds(150,80,80,30);
     t1.setBounds(130,10,100,50);
     l2.setBounds(10,150,200,50);
     b2.setBounds(600,10,80,30);

        Container c = getContentPane();
        c.setBackground(new Color(22,55,46));

        l1.setForeground(Color.white);
        l2.setForeground(Color.white);
    
     
     add(l1);
     add(b1);
     add(l2);
     add(t1);
     add(b2);
    
    }
    public void actionPerformed(ActionEvent e)   
    { 
    Object o=e.getSource();
    if(o==b1)
    {
      double a=Double.parseDouble(t1.getText());
      try
      {
          Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/want2pay", "root", "");
          Statement stmt=con.createStatement();
          System.out.println(email);
          ResultSet rs = stmt.executeQuery("select balance from balance where email=\""+email+"\";");
          rs.next();
          double b = rs.getDouble(1);
          b = b + a;
          stmt.executeUpdate("update balance set balance="+b+" where email=\""+email+"\";");
          stmt.executeUpdate("insert into transaction values(\""+email+"\", \""+email+"\", "+a+", now());");
          l2.setText("Updated Money is:"+ b);
          JOptionPane.showMessageDialog(b1, "Money added Succesfully");

          con.close();
      }
      catch(Exception exception)
      {
          System.out.println(exception);
      }

      }
      if(o==b2)
      {
       dispose();
      new Main(email);
      }
      
    }
//    public static void main(String args[])
//     {
//     new AddMoney();
//     }
}
