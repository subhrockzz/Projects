import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Login extends JFrame implements ActionListener{
    JLabel l1,l2;
    JButton SUBMIT,b1;
    JTextField t1,t2;
    JMenuBar jm;
    Login()
    {
        setVisible(true);
        setSize(800,450);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Login");



        l1 = new JLabel();
        l1.setText("Username:");
        l1.setFont(new Font("Serif",Font.BOLD,22));
        t1 = new JTextField(15);


        l2 = new JLabel();
        l2.setText("Password:");
        t2 = new JPasswordField(15);
        l2.setFont(new Font("Serif",Font.BOLD,22));

        SUBMIT=new JButton("SUBMIT");
        b1=new JButton("Back");
        SUBMIT.setFont(new Font("Serif",Font.BOLD,15));


        SUBMIT.addActionListener(this);
        b1.addActionListener(this);
        setTitle("LOGIN FORM");



        l1.setBounds(10,10,110,50);
        t1.setBounds(130,10,200,50);
        l2.setBounds(10,100,200,50);
        t2.setBounds(130,100,200,50);
        SUBMIT.setBounds(100,250,150,50);
        b1.setBounds(600,10,80,30);

        l1.setForeground(Color.white);
        l2.setForeground(Color.white);
        b1.setBackground(new Color(238,218,214));
        SUBMIT.setBackground(new Color(52,235,189));

        Container c = getContentPane();
        c.setBackground(new Color(22,55,46));


        add(l1);
        add(l2);
        add(t1);
        add(t2);
        add(SUBMIT);
        add(b1);

    }

    public void actionPerformed(ActionEvent ae)
    {
        String value1=t1.getText();
        String value2=t2.getText();
        Object o=ae.getSource();
        if(o==SUBMIT)
        {
            if(value1.length()!=0 && value2.length()!=0) {
                boolean flag = false;
                try {
                    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/want2pay", "root", "");
                    Statement stmt = con.createStatement();
                    ResultSet rs = stmt.executeQuery("select password from info where email=\"" + value1 + "\";");
                    if (rs.next() && rs.getString(1).equals(value2)) {
                        System.out.println(rs.getString(1));
                        flag = true;
                    }
                    con.close();

                } catch (Exception exception) {
                    System.out.println(exception);
                }
                if (flag) {
                    dispose();
                    new Main(value1);
                } else {
                    System.out.println("enter the valid username and password");
                    JOptionPane.showMessageDialog(this, "Incorrect login or password",
                            "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
            else{JOptionPane.showMessageDialog(SUBMIT, "Enter your UserId and Password");}
        }
        if(o==b1)
        {
            dispose();
            new FrontPage();
        }
    }

    public static void main(String arg[])
    {
        new Login();
    }

}

        
        
