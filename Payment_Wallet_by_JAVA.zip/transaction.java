import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class transaction extends JFrame implements ActionListener
{
    String email;
    JTable jt;
    JButton b1;
    public transaction(String email)
    {
        setVisible(true);
        setSize(800, 700);
        this.email = email;

        b1 = new JButton("Back");
        b1.addActionListener(this);
        add(b1);

        String[] columnNames = {"To/From", "Amount", "transaction", "Time"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);

        Container c = getContentPane();
        c.setBackground(new Color(232,247,249));

        try
        {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/want2pay", "root", "");
            Statement stmt=con.createStatement();
            System.out.println(email);
            ResultSet rs = stmt.executeQuery("select * from transaction where email=\""+email+"\";");

            while (rs.next()) {

                double money = rs.getDouble(3);
                String type;
                if(money<0)
                {
                    type = "Debited";
                    money = -money;
                }
                else
                {
                    type = "Credited";
                }

                String[] data = { rs.getString(2), Double.toString(money), type, rs.getString(4)};

                // and add this row of data into the table model
                tableModel.addRow(data);
            }

            jt = new JTable(tableModel);
            con.close();
        }
        catch(Exception exception)
        {
            System.out.println(exception);
        }

        jt.setPreferredScrollableViewportSize(new Dimension(200, 200));
        JScrollPane js = new JScrollPane(jt);
        js.setBounds(10, 10, 200, 200);
        add(js);

        b1.setBounds(700, 350, 100, 30);

    }
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==b1)
        {
            new Main(email);
            dispose();
        }
    }
}
