import javax.swing.*;  
import java.awt.*;  
import java.awt.event.*;
import java.awt.color.*;
public class Main extends JFrame implements ActionListener{
    JLabel l1;
    JButton b1,b2,b3,b4,b5,b6, b7;
    String email;
    Main(String email)
    {
     setVisible(true);  
     setSize(800, 570);
     setLayout(null);  
     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
     setTitle("Homepage");

     this.email = email;
     
     l1 = new JLabel("WANT2PAY");  
     b1 = new JButton("View Profile");
     //b1.setBackground(Color.blue);
     b2 = new JButton("Add Money");  
     b3= new JButton("Pay Money");  
     b4 = new JButton("Check Balance");  
     b5= new JButton("LogOut");  
     b6=new JButton("Back");
     b7=new JButton("Transaction");

     b1.addActionListener(this);  
     b2.addActionListener(this);  
     b3.addActionListener(this);  
     b4.addActionListener(this);  
     b5.addActionListener(this); 
     b6.addActionListener(this); 
     b7.addActionListener(this);

     
     l1.setBounds(10,10,200,50);
     b1.setBounds(50,120,200,50);
     b2.setBounds(500,120,200,50);
     b3.setBounds(50,200,200,50);
     b4.setBounds(500,200,200,50);
     b5.setBounds(300,450,100,50);
     b7.setBounds(250,350,200,50);
     b6.setBounds(600,10,80,30);
     //b6.setBounds(600,10,100,50);
     l1.setFont(new Font("Serif",Font.BOLD,22));
        l1.setForeground(Color.white);

        Container c = getContentPane();
        c.setBackground(new Color(61,33,84));
     
     add(l1);
     add(b1);
     add(b2);
     add(b3);
     add(b4);
     add(b5);
     add(b6);
     add(b7);

     }
     
    public void actionPerformed(ActionEvent e)   
    {  
    Object a=e.getSource();
    
      if(a == b1)
      {
      dispose();
        new Profile(email);
      }
      if(a == b2)
      {
      dispose();
       new AddMoney(email);
      }
      
      if(a == b3)
      {
      dispose();
        new Pay(email);
      }
      if(a == b4)
      {
      dispose();
      new CheckBalance(email);
      
      }
      if(a == b5)
      {
      dispose();
        new FrontPage();
      }
      if(a == b6)
      {
      dispose();
      new FrontPage();
      }
      if(a == b7)
      {
          dispose();
          new transaction(email);

      }
    }  


//     public static void main(String args[])
//     {
//     new Main();
//     }
     }
     
     
     
     
